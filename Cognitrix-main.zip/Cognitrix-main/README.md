# Cognitrix
StudyMate: An AI -Powered PDF Based Q&amp;A System for Students
